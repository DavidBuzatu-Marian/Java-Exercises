package timing;

public enum TimerState {

	Running, Stopped, Paused;
}
