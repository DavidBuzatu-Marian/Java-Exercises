package bench.cpu;

public enum NumberRepresentation {

	FLOATING, FIXED
}
