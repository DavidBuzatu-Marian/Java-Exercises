package graphalgo;

import graphs.Edge;
import graphs.UndirectedGraph;

import java.util.HashSet;
import java.util.Set;


public class KruskalMSTFinder implements IMSTFinder{

	public Set<Edge> mst=new HashSet<Edge>();
	
	@Override
	public Set<Edge> FindMST(UndirectedGraph g) {
						
		// TODO Auto-generated method stub
		System.out.println("Kruskal MST - not yet implemented");
		return null;
			
	}

}
