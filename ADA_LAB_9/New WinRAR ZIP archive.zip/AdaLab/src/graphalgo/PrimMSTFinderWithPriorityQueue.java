package graphalgo;

import graphs.Edge;
import graphs.UndirectedGraph;

import java.util.HashSet;
import java.util.Set;
import priorityqueues.MyPriorityQueue;
import priorityqueues.PriorityQueueImpl;

public class PrimMSTFinderWithPriorityQueue implements IMSTFinder {
	
	
	public Set<Edge> FindMST(UndirectedGraph g) {
		System.out.println("PrimMSTFinderWithPriorityQueue - not yet implemented");
		return null;
		
	}

}
